function tocaSomPom () {
    document.querySelector('#som_tecla_pom').play();
}

document.querySelectorAll
